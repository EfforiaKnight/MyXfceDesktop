#!/bin/sh

# start conky

conky -c /home/efforia-knight/.Conky/Remake/rings -d -p 10 # the main conky with rings
sleep 8 #time for the main conky to start; needed so that the smaller ones draw above not below (probably can be lower, but we still have to wait 5s for the rings to avoid segfaults)
conky -c /home/efforia-knight/.Conky/Remake/cpu -d -p 1
conky -c /home/efforia-knight/.Conky/Remake/mem -d - p 1
conky -c /home/efforia-knight/.Conky/Remake/weather -d -p 1
conky -c /home/efforia-knight/.Conky/Remake/gcal -d -p 1