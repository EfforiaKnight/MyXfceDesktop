# Cloak-3.20
A black transparent theme for Gtk-3.20
