/*
** Lua binding: rsvg
** Generated automatically by tolua++-1.0.92 on Tue Jul 12 21:52:11 2016.
*/

#ifndef __cplusplus
#include "stdlib.h"
#endif
#include "string.h"

#include "tolua++.h"

/* Exported function */
TOLUA_API int  tolua_rsvg_open (lua_State* tolua_S);

#include <glib.h>
#include <librsvg/rsvg.h>
#include "librsvg-helper.h"

/* function to register type */
static void tolua_reg_types (lua_State* tolua_S)
{
 tolua_usertype(tolua_S,"_RsvgHandle");
 tolua_usertype(tolua_S,"cairo_t");
 tolua_usertype(tolua_S,"RsvgDimensionData");
 tolua_usertype(tolua_S,"RsvgHandleFlags");
 tolua_usertype(tolua_S,"gpointer");
 tolua_usertype(tolua_S,"GError");
 tolua_usertype(tolua_S,"RsvgPositionData");
}

/* get function: width of class  RsvgDimensionData */
#ifndef TOLUA_DISABLE_tolua_get_RsvgDimensionData_width
static int tolua_get_RsvgDimensionData_width(lua_State* tolua_S)
{
  RsvgDimensionData* self = (RsvgDimensionData*)  tolua_tousertype(tolua_S,1,0);
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in accessing variable 'width'",NULL);
#endif
  tolua_pushnumber(tolua_S,(lua_Number)self->width);
 return 1;
}
#endif //#ifndef TOLUA_DISABLE

/* set function: width of class  RsvgDimensionData */
#ifndef TOLUA_DISABLE_tolua_set_RsvgDimensionData_width
static int tolua_set_RsvgDimensionData_width(lua_State* tolua_S)
{
  RsvgDimensionData* self = (RsvgDimensionData*)  tolua_tousertype(tolua_S,1,0);
#ifndef TOLUA_RELEASE
  tolua_Error tolua_err;
  if (!self) tolua_error(tolua_S,"invalid 'self' in accessing variable 'width'",NULL);
  if (!tolua_isnumber(tolua_S,2,0,&tolua_err))
   tolua_error(tolua_S,"#vinvalid type in variable assignment.",&tolua_err);
#endif
  self->width = ((int)  tolua_tonumber(tolua_S,2,0))
;
 return 0;
}
#endif //#ifndef TOLUA_DISABLE

/* get function: height of class  RsvgDimensionData */
#ifndef TOLUA_DISABLE_tolua_get_RsvgDimensionData_height
static int tolua_get_RsvgDimensionData_height(lua_State* tolua_S)
{
  RsvgDimensionData* self = (RsvgDimensionData*)  tolua_tousertype(tolua_S,1,0);
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in accessing variable 'height'",NULL);
#endif
  tolua_pushnumber(tolua_S,(lua_Number)self->height);
 return 1;
}
#endif //#ifndef TOLUA_DISABLE

/* set function: height of class  RsvgDimensionData */
#ifndef TOLUA_DISABLE_tolua_set_RsvgDimensionData_height
static int tolua_set_RsvgDimensionData_height(lua_State* tolua_S)
{
  RsvgDimensionData* self = (RsvgDimensionData*)  tolua_tousertype(tolua_S,1,0);
#ifndef TOLUA_RELEASE
  tolua_Error tolua_err;
  if (!self) tolua_error(tolua_S,"invalid 'self' in accessing variable 'height'",NULL);
  if (!tolua_isnumber(tolua_S,2,0,&tolua_err))
   tolua_error(tolua_S,"#vinvalid type in variable assignment.",&tolua_err);
#endif
  self->height = ((int)  tolua_tonumber(tolua_S,2,0))
;
 return 0;
}
#endif //#ifndef TOLUA_DISABLE

/* get function: em of class  RsvgDimensionData */
#ifndef TOLUA_DISABLE_tolua_get_RsvgDimensionData_em
static int tolua_get_RsvgDimensionData_em(lua_State* tolua_S)
{
  RsvgDimensionData* self = (RsvgDimensionData*)  tolua_tousertype(tolua_S,1,0);
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in accessing variable 'em'",NULL);
#endif
  tolua_pushnumber(tolua_S,(lua_Number)self->em);
 return 1;
}
#endif //#ifndef TOLUA_DISABLE

/* set function: em of class  RsvgDimensionData */
#ifndef TOLUA_DISABLE_tolua_set_RsvgDimensionData_em
static int tolua_set_RsvgDimensionData_em(lua_State* tolua_S)
{
  RsvgDimensionData* self = (RsvgDimensionData*)  tolua_tousertype(tolua_S,1,0);
#ifndef TOLUA_RELEASE
  tolua_Error tolua_err;
  if (!self) tolua_error(tolua_S,"invalid 'self' in accessing variable 'em'",NULL);
  if (!tolua_isnumber(tolua_S,2,0,&tolua_err))
   tolua_error(tolua_S,"#vinvalid type in variable assignment.",&tolua_err);
#endif
  self->em = ((double)  tolua_tonumber(tolua_S,2,0))
;
 return 0;
}
#endif //#ifndef TOLUA_DISABLE

/* get function: ex of class  RsvgDimensionData */
#ifndef TOLUA_DISABLE_tolua_get_RsvgDimensionData_ex
static int tolua_get_RsvgDimensionData_ex(lua_State* tolua_S)
{
  RsvgDimensionData* self = (RsvgDimensionData*)  tolua_tousertype(tolua_S,1,0);
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in accessing variable 'ex'",NULL);
#endif
  tolua_pushnumber(tolua_S,(lua_Number)self->ex);
 return 1;
}
#endif //#ifndef TOLUA_DISABLE

/* set function: ex of class  RsvgDimensionData */
#ifndef TOLUA_DISABLE_tolua_set_RsvgDimensionData_ex
static int tolua_set_RsvgDimensionData_ex(lua_State* tolua_S)
{
  RsvgDimensionData* self = (RsvgDimensionData*)  tolua_tousertype(tolua_S,1,0);
#ifndef TOLUA_RELEASE
  tolua_Error tolua_err;
  if (!self) tolua_error(tolua_S,"invalid 'self' in accessing variable 'ex'",NULL);
  if (!tolua_isnumber(tolua_S,2,0,&tolua_err))
   tolua_error(tolua_S,"#vinvalid type in variable assignment.",&tolua_err);
#endif
  self->ex = ((double)  tolua_tonumber(tolua_S,2,0))
;
 return 0;
}
#endif //#ifndef TOLUA_DISABLE

/* method: rsvgDimensionDataCreate of class  RsvgDimensionData */
#ifndef TOLUA_DISABLE_tolua_rsvg_RsvgDimensionData_create00
static int tolua_rsvg_RsvgDimensionData_create00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertable(tolua_S,1,"RsvgDimensionData",0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,2,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  {
   tolua_outside RsvgDimensionData* tolua_ret = (tolua_outside RsvgDimensionData*)  rsvgDimensionDataCreate();
    tolua_pushusertype(tolua_S,(void*)tolua_ret,"RsvgDimensionData");
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'create'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: rsvgDimensionDataGet of class  RsvgDimensionData */
#ifndef TOLUA_DISABLE_tolua_rsvg_RsvgDimensionData_get00
static int tolua_rsvg_RsvgDimensionData_get00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"RsvgDimensionData",0,&tolua_err) ||
     !tolua_isnumber(tolua_S,2,0,&tolua_err) ||
     !tolua_isnumber(tolua_S,3,0,&tolua_err) ||
     !tolua_isnumber(tolua_S,4,0,&tolua_err) ||
     !tolua_isnumber(tolua_S,5,0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,6,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  RsvgDimensionData* self = (RsvgDimensionData*)  tolua_tousertype(tolua_S,1,0);
  int width = ((int)  tolua_tonumber(tolua_S,2,0));
  int height = ((int)  tolua_tonumber(tolua_S,3,0));
  double em = ((double)  tolua_tonumber(tolua_S,4,0));
  double ex = ((double)  tolua_tonumber(tolua_S,5,0));
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'rsvgDimensionDataGet'", NULL);
#endif
  {
   rsvgDimensionDataGet(self,&width,&height,&em,&ex);
   tolua_pushnumber(tolua_S,(lua_Number)width);
   tolua_pushnumber(tolua_S,(lua_Number)height);
   tolua_pushnumber(tolua_S,(lua_Number)em);
   tolua_pushnumber(tolua_S,(lua_Number)ex);
  }
 }
 return 4;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'get'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* get function: x of class  RsvgPositionData */
#ifndef TOLUA_DISABLE_tolua_get_RsvgPositionData_x
static int tolua_get_RsvgPositionData_x(lua_State* tolua_S)
{
  RsvgPositionData* self = (RsvgPositionData*)  tolua_tousertype(tolua_S,1,0);
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in accessing variable 'x'",NULL);
#endif
  tolua_pushnumber(tolua_S,(lua_Number)self->x);
 return 1;
}
#endif //#ifndef TOLUA_DISABLE

/* set function: x of class  RsvgPositionData */
#ifndef TOLUA_DISABLE_tolua_set_RsvgPositionData_x
static int tolua_set_RsvgPositionData_x(lua_State* tolua_S)
{
  RsvgPositionData* self = (RsvgPositionData*)  tolua_tousertype(tolua_S,1,0);
#ifndef TOLUA_RELEASE
  tolua_Error tolua_err;
  if (!self) tolua_error(tolua_S,"invalid 'self' in accessing variable 'x'",NULL);
  if (!tolua_isnumber(tolua_S,2,0,&tolua_err))
   tolua_error(tolua_S,"#vinvalid type in variable assignment.",&tolua_err);
#endif
  self->x = ((int)  tolua_tonumber(tolua_S,2,0))
;
 return 0;
}
#endif //#ifndef TOLUA_DISABLE

/* get function: y of class  RsvgPositionData */
#ifndef TOLUA_DISABLE_tolua_get_RsvgPositionData_y
static int tolua_get_RsvgPositionData_y(lua_State* tolua_S)
{
  RsvgPositionData* self = (RsvgPositionData*)  tolua_tousertype(tolua_S,1,0);
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in accessing variable 'y'",NULL);
#endif
  tolua_pushnumber(tolua_S,(lua_Number)self->y);
 return 1;
}
#endif //#ifndef TOLUA_DISABLE

/* set function: y of class  RsvgPositionData */
#ifndef TOLUA_DISABLE_tolua_set_RsvgPositionData_y
static int tolua_set_RsvgPositionData_y(lua_State* tolua_S)
{
  RsvgPositionData* self = (RsvgPositionData*)  tolua_tousertype(tolua_S,1,0);
#ifndef TOLUA_RELEASE
  tolua_Error tolua_err;
  if (!self) tolua_error(tolua_S,"invalid 'self' in accessing variable 'y'",NULL);
  if (!tolua_isnumber(tolua_S,2,0,&tolua_err))
   tolua_error(tolua_S,"#vinvalid type in variable assignment.",&tolua_err);
#endif
  self->y = ((int)  tolua_tonumber(tolua_S,2,0))
;
 return 0;
}
#endif //#ifndef TOLUA_DISABLE

/* method: rsvgPositionDataCreate of class  RsvgPositionData */
#ifndef TOLUA_DISABLE_tolua_rsvg_RsvgPositionData_create00
static int tolua_rsvg_RsvgPositionData_create00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertable(tolua_S,1,"RsvgPositionData",0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,2,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  {
   tolua_outside RsvgPositionData* tolua_ret = (tolua_outside RsvgPositionData*)  rsvgPositionDataCreate();
    tolua_pushusertype(tolua_S,(void*)tolua_ret,"RsvgPositionData");
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'create'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: rsvgPositionDataGet of class  RsvgPositionData */
#ifndef TOLUA_DISABLE_tolua_rsvg_RsvgPositionData_get00
static int tolua_rsvg_RsvgPositionData_get00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"RsvgPositionData",0,&tolua_err) ||
     !tolua_isnumber(tolua_S,2,0,&tolua_err) ||
     !tolua_isnumber(tolua_S,3,0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,4,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  RsvgPositionData* self = (RsvgPositionData*)  tolua_tousertype(tolua_S,1,0);
  int x = ((int)  tolua_tonumber(tolua_S,2,0));
  int y = ((int)  tolua_tonumber(tolua_S,3,0));
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'rsvgPositionDataGet'", NULL);
#endif
  {
   rsvgPositionDataGet(self,&x,&y);
   tolua_pushnumber(tolua_S,(lua_Number)x);
   tolua_pushnumber(tolua_S,(lua_Number)y);
  }
 }
 return 2;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'get'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* function: rsvg_handle_new */
#ifndef TOLUA_DISABLE_tolua_rsvg_rsvg_handle_new00
static int tolua_rsvg_rsvg_handle_new00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isnoobj(tolua_S,1,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  {
   struct _RsvgHandle* tolua_ret = ( struct _RsvgHandle*)  rsvg_handle_new();
    tolua_pushusertype(tolua_S,(void*)tolua_ret,"_RsvgHandle");
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'rsvg_handle_new'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* function: rsvg_handle_write */
#ifndef TOLUA_DISABLE_tolua_rsvg_rsvg_handle_write00
static int tolua_rsvg_rsvg_handle_write00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"_RsvgHandle",0,&tolua_err) ||
     !tolua_isstring(tolua_S,2,0,&tolua_err) ||
     !tolua_isnumber(tolua_S,3,0,&tolua_err) ||
     !tolua_isusertype(tolua_S,4,"GError",0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,5,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  struct _RsvgHandle* handle = (( struct _RsvgHandle*)  tolua_tousertype(tolua_S,1,0));
  unsigned const char* buf = ((unsigned const char*)  tolua_tostring(tolua_S,2,0));
  unsigned long count = ((unsigned long)  tolua_tonumber(tolua_S,3,0));
  GError* error = ((GError*)  tolua_tousertype(tolua_S,4,0));
  {
   int tolua_ret = (int)  rsvg_handle_write(handle,buf,count,&error);
   tolua_pushnumber(tolua_S,(lua_Number)tolua_ret);
    tolua_pushusertype(tolua_S,(void*)error,"GError");
  }
 }
 return 2;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'rsvg_handle_write'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* function: rsvg_handle_close */
#ifndef TOLUA_DISABLE_tolua_rsvg_rsvg_handle_close00
static int tolua_rsvg_rsvg_handle_close00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"_RsvgHandle",0,&tolua_err) ||
     !tolua_isusertype(tolua_S,2,"GError",0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,3,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  struct _RsvgHandle* handle = (( struct _RsvgHandle*)  tolua_tousertype(tolua_S,1,0));
  GError* error = ((GError*)  tolua_tousertype(tolua_S,2,0));
  {
   int tolua_ret = (int)  rsvg_handle_close(handle,&error);
   tolua_pushnumber(tolua_S,(lua_Number)tolua_ret);
    tolua_pushusertype(tolua_S,(void*)error,"GError");
  }
 }
 return 2;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'rsvg_handle_close'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* function: rsvg_handle_get_base_uri */
#ifndef TOLUA_DISABLE_tolua_rsvg_rsvg_handle_get_base_uri00
static int tolua_rsvg_rsvg_handle_get_base_uri00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"_RsvgHandle",0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,2,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  struct _RsvgHandle* handle = (( struct _RsvgHandle*)  tolua_tousertype(tolua_S,1,0));
  {
   const char* tolua_ret = (const char*)  rsvg_handle_get_base_uri(handle);
   tolua_pushstring(tolua_S,(const char*)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'rsvg_handle_get_base_uri'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* function: rsvg_handle_set_base_uri */
#ifndef TOLUA_DISABLE_tolua_rsvg_rsvg_handle_set_base_uri00
static int tolua_rsvg_rsvg_handle_set_base_uri00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"_RsvgHandle",0,&tolua_err) ||
     !tolua_isstring(tolua_S,2,0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,3,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  struct _RsvgHandle* handle = (( struct _RsvgHandle*)  tolua_tousertype(tolua_S,1,0));
  const char* base_uri = ((const char*)  tolua_tostring(tolua_S,2,0));
  {
   rsvg_handle_set_base_uri(handle,base_uri);
  }
 }
 return 0;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'rsvg_handle_set_base_uri'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* function: rsvg_handle_get_dimensions */
#ifndef TOLUA_DISABLE_tolua_rsvg_rsvg_handle_get_dimensions00
static int tolua_rsvg_rsvg_handle_get_dimensions00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"_RsvgHandle",0,&tolua_err) ||
     !tolua_isusertype(tolua_S,2,"RsvgDimensionData",0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,3,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  struct _RsvgHandle* handle = (( struct _RsvgHandle*)  tolua_tousertype(tolua_S,1,0));
  RsvgDimensionData* dimension_data = ((RsvgDimensionData*)  tolua_tousertype(tolua_S,2,0));
  {
   rsvg_handle_get_dimensions(handle,dimension_data);
  }
 }
 return 0;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'rsvg_handle_get_dimensions'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* function: rsvg_handle_get_dimensions_sub */
#ifndef TOLUA_DISABLE_tolua_rsvg_rsvg_handle_get_dimensions_sub00
static int tolua_rsvg_rsvg_handle_get_dimensions_sub00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"_RsvgHandle",0,&tolua_err) ||
     !tolua_isusertype(tolua_S,2,"RsvgDimensionData",0,&tolua_err) ||
     !tolua_isstring(tolua_S,3,0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,4,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  struct _RsvgHandle* handle = (( struct _RsvgHandle*)  tolua_tousertype(tolua_S,1,0));
  RsvgDimensionData* dimension_data = ((RsvgDimensionData*)  tolua_tousertype(tolua_S,2,0));
  const char* id = ((const char*)  tolua_tostring(tolua_S,3,0));
  {
   int tolua_ret = (int)  rsvg_handle_get_dimensions_sub(handle,dimension_data,id);
   tolua_pushnumber(tolua_S,(lua_Number)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'rsvg_handle_get_dimensions_sub'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* function: rsvg_handle_get_position_sub */
#ifndef TOLUA_DISABLE_tolua_rsvg_rsvg_handle_get_position_sub00
static int tolua_rsvg_rsvg_handle_get_position_sub00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"_RsvgHandle",0,&tolua_err) ||
     !tolua_isusertype(tolua_S,2,"RsvgPositionData",0,&tolua_err) ||
     !tolua_isstring(tolua_S,3,0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,4,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  struct _RsvgHandle* handle = (( struct _RsvgHandle*)  tolua_tousertype(tolua_S,1,0));
  RsvgPositionData* position_data = ((RsvgPositionData*)  tolua_tousertype(tolua_S,2,0));
  const char* id = ((const char*)  tolua_tostring(tolua_S,3,0));
  {
   int tolua_ret = (int)  rsvg_handle_get_position_sub(handle,position_data,id);
   tolua_pushnumber(tolua_S,(lua_Number)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'rsvg_handle_get_position_sub'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* function: rsvg_handle_has_sub */
#ifndef TOLUA_DISABLE_tolua_rsvg_rsvg_handle_has_sub00
static int tolua_rsvg_rsvg_handle_has_sub00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"_RsvgHandle",0,&tolua_err) ||
     !tolua_isstring(tolua_S,2,0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,3,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  struct _RsvgHandle* handle = (( struct _RsvgHandle*)  tolua_tousertype(tolua_S,1,0));
  const char* id = ((const char*)  tolua_tostring(tolua_S,2,0));
  {
   int tolua_ret = (int)  rsvg_handle_has_sub(handle,id);
   tolua_pushnumber(tolua_S,(lua_Number)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'rsvg_handle_has_sub'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* function: rsvg_handle_new_with_flags */
#ifndef TOLUA_DISABLE_tolua_rsvg_rsvg_handle_new_with_flags00
static int tolua_rsvg_rsvg_handle_new_with_flags00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     (tolua_isvaluenil(tolua_S,1,&tolua_err) || !tolua_isusertype(tolua_S,1,"RsvgHandleFlags",0,&tolua_err)) ||
     !tolua_isnoobj(tolua_S,2,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  RsvgHandleFlags flags = *((RsvgHandleFlags*)  tolua_tousertype(tolua_S,1,0));
  {
   struct _RsvgHandle* tolua_ret = ( struct _RsvgHandle*)  rsvg_handle_new_with_flags(flags);
    tolua_pushusertype(tolua_S,(void*)tolua_ret,"_RsvgHandle");
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'rsvg_handle_new_with_flags'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* function: rsvg_handle_new_from_data */
#ifndef TOLUA_DISABLE_tolua_rsvg_rsvg_handle_new_from_data00
static int tolua_rsvg_rsvg_handle_new_from_data00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isstring(tolua_S,1,0,&tolua_err) ||
     !tolua_isnumber(tolua_S,2,0,&tolua_err) ||
     !tolua_isusertype(tolua_S,3,"GError",0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,4,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  unsigned const char* data = ((unsigned const char*)  tolua_tostring(tolua_S,1,0));
  unsigned long data_len = ((unsigned long)  tolua_tonumber(tolua_S,2,0));
  GError* error = ((GError*)  tolua_tousertype(tolua_S,3,0));
  {
   struct _RsvgHandle* tolua_ret = ( struct _RsvgHandle*)  rsvg_handle_new_from_data(data,data_len,&error);
    tolua_pushusertype(tolua_S,(void*)tolua_ret,"_RsvgHandle");
    tolua_pushusertype(tolua_S,(void*)error,"GError");
  }
 }
 return 2;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'rsvg_handle_new_from_data'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* function: rsvg_handle_new_from_file */
#ifndef TOLUA_DISABLE_tolua_rsvg_rsvg_handle_new_from_file00
static int tolua_rsvg_rsvg_handle_new_from_file00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isstring(tolua_S,1,0,&tolua_err) ||
     !tolua_isusertype(tolua_S,2,"GError",0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,3,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  const char* file_name = ((const char*)  tolua_tostring(tolua_S,1,0));
  GError* error = ((GError*)  tolua_tousertype(tolua_S,2,0));
  {
   struct _RsvgHandle* tolua_ret = ( struct _RsvgHandle*)  rsvg_handle_new_from_file(file_name,&error);
    tolua_pushusertype(tolua_S,(void*)tolua_ret,"_RsvgHandle");
    tolua_pushusertype(tolua_S,(void*)error,"GError");
  }
 }
 return 2;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'rsvg_handle_new_from_file'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* function: rsvg_handle_render_cairo */
#ifndef TOLUA_DISABLE_tolua_rsvg_rsvg_handle_render_cairo00
static int tolua_rsvg_rsvg_handle_render_cairo00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"_RsvgHandle",0,&tolua_err) ||
     !tolua_isusertype(tolua_S,2,"cairo_t",0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,3,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  struct _RsvgHandle* handle = (( struct _RsvgHandle*)  tolua_tousertype(tolua_S,1,0));
  cairo_t* cr = ((cairo_t*)  tolua_tousertype(tolua_S,2,0));
  {
   int tolua_ret = (int)  rsvg_handle_render_cairo(handle,cr);
   tolua_pushnumber(tolua_S,(lua_Number)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'rsvg_handle_render_cairo'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* function: rsvg_handle_render_cairo_sub */
#ifndef TOLUA_DISABLE_tolua_rsvg_rsvg_handle_render_cairo_sub00
static int tolua_rsvg_rsvg_handle_render_cairo_sub00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"_RsvgHandle",0,&tolua_err) ||
     !tolua_isusertype(tolua_S,2,"cairo_t",0,&tolua_err) ||
     !tolua_isstring(tolua_S,3,0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,4,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  struct _RsvgHandle* handle = (( struct _RsvgHandle*)  tolua_tousertype(tolua_S,1,0));
  cairo_t* cr = ((cairo_t*)  tolua_tousertype(tolua_S,2,0));
  const char* id = ((const char*)  tolua_tostring(tolua_S,3,0));
  {
   int tolua_ret = (int)  rsvg_handle_render_cairo_sub(handle,cr,id);
   tolua_pushnumber(tolua_S,(lua_Number)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'rsvg_handle_render_cairo_sub'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* function: g_type_init */
#ifndef TOLUA_DISABLE_tolua_rsvg_g_type_init00
static int tolua_rsvg_g_type_init00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isnoobj(tolua_S,1,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  {
   g_type_init();
  }
 }
 return 0;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'g_type_init'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* function: g_object_unref */
#ifndef TOLUA_DISABLE_tolua_rsvg_g_object_unref00
static int tolua_rsvg_g_object_unref00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     (tolua_isvaluenil(tolua_S,1,&tolua_err) || !tolua_isusertype(tolua_S,1,"gpointer",0,&tolua_err)) ||
     !tolua_isnoobj(tolua_S,2,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  gpointer object = *((gpointer*)  tolua_tousertype(tolua_S,1,0));
  {
   g_object_unref(object);
  }
 }
 return 0;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'g_object_unref'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* function: rsvg_create_handle_from_file */
#ifndef TOLUA_DISABLE_tolua_rsvg_rsvg_create_handle_from_file00
static int tolua_rsvg_rsvg_create_handle_from_file00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isstring(tolua_S,1,0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,2,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  const char* tolua_var_1 = ((const char*)  tolua_tostring(tolua_S,1,0));
  {
   struct _RsvgHandle* tolua_ret = ( struct _RsvgHandle*)  rsvg_create_handle_from_file(tolua_var_1);
    tolua_pushusertype(tolua_S,(void*)tolua_ret,"_RsvgHandle");
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'rsvg_create_handle_from_file'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* function: rsvg_destroy_handle */
#ifndef TOLUA_DISABLE_tolua_rsvg_rsvg_destroy_handle00
static int tolua_rsvg_rsvg_destroy_handle00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"_RsvgHandle",0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,2,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  struct _RsvgHandle* tolua_var_2 = (( struct _RsvgHandle*)  tolua_tousertype(tolua_S,1,0));
  {
   int tolua_ret = (int)  rsvg_destroy_handle(tolua_var_2);
   tolua_pushnumber(tolua_S,(lua_Number)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'rsvg_destroy_handle'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* Open function */
TOLUA_API int tolua_rsvg_open (lua_State* tolua_S)
{
 tolua_open(tolua_S);
 tolua_reg_types(tolua_S);
 tolua_module(tolua_S,NULL,0);
 tolua_beginmodule(tolua_S,NULL);
  tolua_cclass(tolua_S,"RsvgDimensionData","RsvgDimensionData","",NULL);
  tolua_beginmodule(tolua_S,"RsvgDimensionData");
   tolua_variable(tolua_S,"width",tolua_get_RsvgDimensionData_width,tolua_set_RsvgDimensionData_width);
   tolua_variable(tolua_S,"height",tolua_get_RsvgDimensionData_height,tolua_set_RsvgDimensionData_height);
   tolua_variable(tolua_S,"em",tolua_get_RsvgDimensionData_em,tolua_set_RsvgDimensionData_em);
   tolua_variable(tolua_S,"ex",tolua_get_RsvgDimensionData_ex,tolua_set_RsvgDimensionData_ex);
   tolua_function(tolua_S,"create",tolua_rsvg_RsvgDimensionData_create00);
   tolua_function(tolua_S,"get",tolua_rsvg_RsvgDimensionData_get00);
  tolua_endmodule(tolua_S);
  tolua_cclass(tolua_S,"RsvgPositionData","RsvgPositionData","",NULL);
  tolua_beginmodule(tolua_S,"RsvgPositionData");
   tolua_variable(tolua_S,"x",tolua_get_RsvgPositionData_x,tolua_set_RsvgPositionData_x);
   tolua_variable(tolua_S,"y",tolua_get_RsvgPositionData_y,tolua_set_RsvgPositionData_y);
   tolua_function(tolua_S,"create",tolua_rsvg_RsvgPositionData_create00);
   tolua_function(tolua_S,"get",tolua_rsvg_RsvgPositionData_get00);
  tolua_endmodule(tolua_S);
  tolua_function(tolua_S,"rsvg_handle_new",tolua_rsvg_rsvg_handle_new00);
  tolua_function(tolua_S,"rsvg_handle_write",tolua_rsvg_rsvg_handle_write00);
  tolua_function(tolua_S,"rsvg_handle_close",tolua_rsvg_rsvg_handle_close00);
  tolua_function(tolua_S,"rsvg_handle_get_base_uri",tolua_rsvg_rsvg_handle_get_base_uri00);
  tolua_function(tolua_S,"rsvg_handle_set_base_uri",tolua_rsvg_rsvg_handle_set_base_uri00);
  tolua_function(tolua_S,"rsvg_handle_get_dimensions",tolua_rsvg_rsvg_handle_get_dimensions00);
  tolua_function(tolua_S,"rsvg_handle_get_dimensions_sub",tolua_rsvg_rsvg_handle_get_dimensions_sub00);
  tolua_function(tolua_S,"rsvg_handle_get_position_sub",tolua_rsvg_rsvg_handle_get_position_sub00);
  tolua_function(tolua_S,"rsvg_handle_has_sub",tolua_rsvg_rsvg_handle_has_sub00);
  tolua_function(tolua_S,"rsvg_handle_new_with_flags",tolua_rsvg_rsvg_handle_new_with_flags00);
  tolua_function(tolua_S,"rsvg_handle_new_from_data",tolua_rsvg_rsvg_handle_new_from_data00);
  tolua_function(tolua_S,"rsvg_handle_new_from_file",tolua_rsvg_rsvg_handle_new_from_file00);
  tolua_function(tolua_S,"rsvg_handle_render_cairo",tolua_rsvg_rsvg_handle_render_cairo00);
  tolua_function(tolua_S,"rsvg_handle_render_cairo_sub",tolua_rsvg_rsvg_handle_render_cairo_sub00);
  tolua_function(tolua_S,"g_type_init",tolua_rsvg_g_type_init00);
  tolua_function(tolua_S,"g_object_unref",tolua_rsvg_g_object_unref00);
  tolua_function(tolua_S,"rsvg_create_handle_from_file",tolua_rsvg_rsvg_create_handle_from_file00);
  tolua_function(tolua_S,"rsvg_destroy_handle",tolua_rsvg_rsvg_destroy_handle00);
 tolua_endmodule(tolua_S);
 return 1;
}


#if defined(LUA_VERSION_NUM) && LUA_VERSION_NUM >= 501
 TOLUA_API int luaopen_rsvg (lua_State* tolua_S) {
 return tolua_rsvg_open(tolua_S);
};
#endif

