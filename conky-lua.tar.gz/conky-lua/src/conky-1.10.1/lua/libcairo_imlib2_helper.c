/*
** Lua binding: cairo_imlib2_helper
** Generated automatically by tolua++-1.0.92 on Tue Jul 12 21:52:11 2016.
*/

#ifndef __cplusplus
#include "stdlib.h"
#endif
#include "string.h"

#include "tolua++.h"

/* Exported function */
TOLUA_API int  tolua_cairo_imlib2_helper_open (lua_State* tolua_S);

#include <cairo.h>
#include <libcairo_imlib2_helper.h>

/* function to register type */
static void tolua_reg_types (lua_State* tolua_S)
{
 tolua_usertype(tolua_S,"cairo_surface_t");
}

/* function: cairo_draw_image */
#ifndef TOLUA_DISABLE_tolua_cairo_imlib2_helper_cairo_draw_image00
static int tolua_cairo_imlib2_helper_cairo_draw_image00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isstring(tolua_S,1,0,&tolua_err) ||
     !tolua_isusertype(tolua_S,2,"cairo_surface_t",0,&tolua_err) ||
     !tolua_isnumber(tolua_S,3,0,&tolua_err) ||
     !tolua_isnumber(tolua_S,4,0,&tolua_err) ||
     !tolua_isnumber(tolua_S,5,0,&tolua_err) ||
     !tolua_isnumber(tolua_S,6,0,&tolua_err) ||
     !tolua_isnumber(tolua_S,7,0,&tolua_err) ||
     !tolua_isnumber(tolua_S,8,0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,9,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  const char* tolua_var_1 = ((const char*)  tolua_tostring(tolua_S,1,0));
  cairo_surface_t* tolua_var_2 = ((cairo_surface_t*)  tolua_tousertype(tolua_S,2,0));
  int tolua_var_3 = ((int)  tolua_tonumber(tolua_S,3,0));
  int tolua_var_4 = ((int)  tolua_tonumber(tolua_S,4,0));
  double tolua_var_5 = ((double)  tolua_tonumber(tolua_S,5,0));
  double tolua_var_6 = ((double)  tolua_tonumber(tolua_S,6,0));
  double return_scale_w = ((double)  tolua_tonumber(tolua_S,7,0));
  double return_scale_h = ((double)  tolua_tonumber(tolua_S,8,0));
  {
   cairo_draw_image(tolua_var_1,tolua_var_2,tolua_var_3,tolua_var_4,tolua_var_5,tolua_var_6,&return_scale_w,&return_scale_h);
   tolua_pushnumber(tolua_S,(lua_Number)return_scale_w);
   tolua_pushnumber(tolua_S,(lua_Number)return_scale_h);
  }
 }
 return 2;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'cairo_draw_image'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* Open function */
TOLUA_API int tolua_cairo_imlib2_helper_open (lua_State* tolua_S)
{
 tolua_open(tolua_S);
 tolua_reg_types(tolua_S);
 tolua_module(tolua_S,NULL,0);
 tolua_beginmodule(tolua_S,NULL);
  tolua_function(tolua_S,"cairo_draw_image",tolua_cairo_imlib2_helper_cairo_draw_image00);
 tolua_endmodule(tolua_S);
 return 1;
}


#if defined(LUA_VERSION_NUM) && LUA_VERSION_NUM >= 501
 TOLUA_API int luaopen_cairo_imlib2_helper (lua_State* tolua_S) {
 return tolua_cairo_imlib2_helper_open(tolua_S);
};
#endif

