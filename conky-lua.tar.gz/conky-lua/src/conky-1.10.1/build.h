#ifndef __BUILD_H
#define __BUILD_H

/* Conky build info */

#define BUILD_DATE "Tue Jul 12 21:52:10 IDT 2016"
#define BUILD_ARCH "Linux 4.6.2-1-MANJARO x86_64"

#endif /* __BUILD_H */
